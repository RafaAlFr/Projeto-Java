package controller;
import been.Usuario;

public class ControllerUsuario {
public class daoUsuario{
	public Usuario cadastrar(Usuario usu) {
		Usuario saidaUsu = usu;
		return saidaUsu;
	}
	public Usuario listar(Usuario usu) {
		Usuario saidaUsu = usu;
		return saidaUsu;
	}
}
	daoUsuario daoUsu;
	public Usuario cadastrar(Usuario usu) {
		daoUsu = new daoUsuario();
		Usuario saidaUsu = daoUsu.cadastrar(usu);
		return saidaUsu;
	}
	public Usuario listar(Usuario usu) {
		daoUsu = new daoUsuario();
		Usuario saidaUsu = daoUsu.listar(usu);
		return saidaUsu;
	}
}
