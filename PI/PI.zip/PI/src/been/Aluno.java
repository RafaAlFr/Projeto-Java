package been;

public class Aluno {
	private String periodo;
    private String instituicao;
    private String curso;
    private String autor;
    private String apresentador;
    private String presenca;

    public Aluno(String periodo, String instituicao, String curso, String autor, String apresentador, String presenca) {
        this.periodo = periodo;
        this.instituicao = instituicao;
        this.curso = curso;
        this.autor = autor;
        this.apresentador = apresentador;
        this.presenca = presenca;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public String getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getApresentador() {
        return apresentador;
    }

    public void setApresentador(String apresentador) {
        this.apresentador = apresentador;
    }

    public String getPresenca() {
        return presenca;
    }

    public void setPresenca(String presenca) {
        this.presenca = presenca;
    }

    @Override
    public String toString() {
        return "Aluno{" + "periodo=" + periodo + ", instituicao=" + instituicao + ", curso=" + curso + ", autor=" + autor + ", apresentador=" + apresentador + ", presenca=" + presenca + '}';
    }
}
