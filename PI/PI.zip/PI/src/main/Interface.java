package main;

public class Interface {

}
