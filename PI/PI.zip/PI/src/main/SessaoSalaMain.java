package main;

public class SessaoSalaMain {

}
