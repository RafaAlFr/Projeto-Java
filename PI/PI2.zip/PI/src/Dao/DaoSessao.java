package Dao;

import been.Sessao;

public class DaoSessao {

	public Sessao horario(Sessao ses) {
		Sessao saidaSes = ses;
		return saidaSes;
	}
		public Sessao distribuir(Sessao ses) {
			Sessao saidaSes = ses;
			return saidaSes;
		}
		public Sessao listarSessao(Sessao ses) {
			Sessao saidaSes = ses;
			return saidaSes;
		}
	
}
