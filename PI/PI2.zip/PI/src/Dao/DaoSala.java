package Dao;

import been.Sala;

public class DaoSala {
		public Sala cadastrar(Sala sal) {
			Sala saidaSal = sal;
			return saidaSal;
		}
		public Sala listarSala(Sala sal) {
			Sala saidaSal = sal;
			return saidaSal;
		}
	
}
