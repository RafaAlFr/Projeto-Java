package Dao;

import been.Comissao;

public class DaoComissao {
	
		public Comissao CadastrarComissao(Comissao com){
			Comissao saidaCom = com;
			return saidaCom;
		}
	 	
		public Comissao listarComissao(Comissao com){
			Comissao saidaCom = com;
			return saidaCom;
		}
		
		public Comissao editarComissao(Comissao com){
			Comissao saidaCom = com;
			return saidaCom;
		}
		
		public Comissao loginComissao(Comissao com){
			Comissao saidaCom = com;
			return saidaCom;
		}
}
