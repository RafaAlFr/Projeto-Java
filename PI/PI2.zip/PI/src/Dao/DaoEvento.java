package Dao;
import been.Evento;

public class DaoEvento {
	public Evento criar(Evento eve){
		Evento saidaEve = eve;
		return saidaEve;
	}
 	
	public Evento listar(Evento eve){
		Evento saidaEve = eve;
		return saidaEve;
	}
	public Evento editar(Evento eve){
		Evento saidaEve = eve;
		return saidaEve;
	}
}
