package controller;
import been.Sessao;
import Dao.DaoSessao;


public class ControllerSessao {
	DaoSessao daoses;
	
	public Sessao horario(Sessao ses) {
		daoses = new DaoSessao();
		Sessao saidaSes = daoses.horario(ses);
		return saidaSes;
	}
	
	public Sessao distribuir(Sessao ses) {
		daoses = new DaoSessao();
		Sessao saidaSes = daoses.distribuir(ses);
		return saidaSes;
	}
	public Sessao listarSessao(Sessao ses) {
		daoses = new DaoSessao();
		Sessao saidaSes = daoses.listarSessao(ses);
		return saidaSes;
	}
	
}

