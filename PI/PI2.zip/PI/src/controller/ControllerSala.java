package controller;

import Dao.DaoSala;
import been.Sala;

public class ControllerSala {
	DaoSala daoSal;

	public Sala cadastrar(Sala sal) {
		daoSal = new DaoSala();
		Sala saidaSal = daoSal.cadastrar(sal);
		return saidaSal;
	}
	public Sala listarSala(Sala sal) {
		daoSal = new DaoSala();
		Sala saidaSal = daoSal.listarSala(sal);
		return saidaSal;
	}
}

