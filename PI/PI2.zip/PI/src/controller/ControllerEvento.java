package controller;
import been.Evento;
import Dao.DaoEvento;

public class ControllerEvento {
	DaoEvento daoEve;

	public Evento criar(Evento eve) {
		daoEve = new DaoEvento();
		Evento saidaEve = daoEve.criar(eve);
		return saidaEve;
	}
	public Evento listar(Evento eve) {
		daoEve = new DaoEvento();
		Evento saidaEve = daoEve.listar(eve);
		return saidaEve;
	}
	public Evento editar(Evento eve) {
		daoEve = new DaoEvento();
		Evento saidaEve = daoEve.editar(eve);
		return saidaEve;
	}
}

