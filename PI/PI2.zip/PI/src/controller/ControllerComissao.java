package controller;

import Dao.DaoComissao;
import been.Comissao;

public class ControllerComissao {
	DaoComissao daoCom;

	public Comissao CadastrarComissao(Comissao com) {
		daoCom = new DaoComissao();
		Comissao saidaCom = daoCom.CadastrarComissao(com);
		return saidaCom;
	}
	public Comissao listarComissao(Comissao com) {
		daoCom = new DaoComissao();
		Comissao saidaCom = daoCom.listarComissao(com);
		return saidaCom;
	}
	public Comissao editarComissao(Comissao com) {
		daoCom = new DaoComissao();
		Comissao saidaCom = daoCom.editarComissao(com);
		return saidaCom;
	}
	public Comissao loginComissao(Comissao com) {
		daoCom = new DaoComissao();
		Comissao saidaCom = daoCom.loginComissao(com);
		return saidaCom;
	}
}
