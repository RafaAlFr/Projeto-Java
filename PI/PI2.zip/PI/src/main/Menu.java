package main;
import javax.swing.JOptionPane;
public class Menu {
	public static void main(String[]args) {
		 String[] incio = { "Login ADM", "FastEvenTec"};
		    var tipo = (String) JOptionPane.showInputDialog(null, "Menu Principal", "Tipo de login", JOptionPane.QUESTION_MESSAGE, null, // Use
	                                                                // default                                                            // icon
		        incio, // Array of choices
		        incio[0]); // Initial choice
		 switch(tipo) {
		 case "Login ADM":
		 	    validacaoADM();
		    	mainADM();
		 	 break;
		 case "FastEvenTec":
			 FastEvenTec();
			 break;
		 }
		 
	}
	
	public static void FastEvenTec() {
	    ViewUsuario com = new ViewUsuario();
		 String[] opcoes = { "login Comissao", "login Alun", "Sala", "Sessao", "Estatistica", "voltar"};
		    var input = (String) JOptionPane.showInputDialog(null, "Bem Vindo!!:", "Opções do evento", JOptionPane.QUESTION_MESSAGE, null, // Use
	                                                                // default                                                            // icon
		        opcoes, // Array of choices
		        opcoes[0]); // Initial choice
		        switch (input) {
		            case "login Comissao":
		            	com.loginComissao();
		                break;
		            case "Evento":
		            	Evento();
		                break;
		            case "Sala":
		            	Sala();
		                break;
		            case "voltar":
		                mainADM();
		                break;
		  }
	}
		 
	public static void mainADM() {
		 String[] opcoes = { "Comissao", "Evento", "Sala", "Sessao", "Finalizar Sessao"};
		    var input = (String) JOptionPane.showInputDialog(null, "Bem Vindo!!:", "Opções do evento", JOptionPane.QUESTION_MESSAGE, null, // Use
	                                                                // default                                                            // icon
		        opcoes, // Array of choices
		        opcoes[0]); // Initial choice
		        switch (input) {
		            case "Comissao":
		            	Comissao();
		                break;
		            case "Evento":
		            	Evento();
		                break;
		            case "Sala":
		            	Sala();
		                break;
		            case "Sessao":
		            	Sessao();
		                break;
		            case "Finalizar Sessao":
		                System.out.println("Sessão finalizada");
		                Menu.main(null);
		                break;
		            
		  }
	}
		 

	public static boolean validacaoADM() {
	    String s = "yey";
	    String e = "adm";
	    for (int i = 0; i < 3; i++) {
	        String email = JOptionPane.showInputDialog(null, "Insira o email");
	        String senha = JOptionPane.showInputDialog(null, "Insira a senha");
	        if (email.equals(e) && senha.equals(s)) {
	            JOptionPane.showMessageDialog(null, "Bem Vindo!");
	            return true;
	        }
	    }
	    JOptionPane.showMessageDialog(null, "Quantidade máxia de tentativas alcançadas");
	    main(null);
	    return false;
		}
	
	public static void Evento() {
	    Interface eve = new Interface();
		 String[] opcoes = { "Criar Evento", "Listar Evento", "Editar Evento","voltar"};
		    var input = (String) JOptionPane.showInputDialog(null, "Opções para evento:", "selecione a escolhida", JOptionPane.QUESTION_MESSAGE, null, // Use
	                                                                // default                                                            // icon
		        opcoes, // Array of choices
		        opcoes[0]); // Initial choice
		        switch (input) {
		            case "Criar Evento":
		            	eve.criar();
		                break;
		            case "Listar Evento":
		            	eve.listar();
		                break;
		            case "Editar Evento":
		                break;
		            case "voltar":
		                mainADM();
		                break;
		            
		  }
	}
	
	public static void Comissao() {
	    ViewUsuario com = new ViewUsuario();
		 String[] opcoes = { "Cadastrar Comissao", "Listar Comissao", "Editar Comissao","voltar"};
		    var input = (String) JOptionPane.showInputDialog(null, "Opções para Comissao:", "selecione uma opção", JOptionPane.QUESTION_MESSAGE, null, // Use
	                                                                // default                                                            // icon
		        opcoes, // Array of choices
		        opcoes[0]); // Initial choice
		        switch (input) {
		            case "Cadastrar Comissao":
		            	com.cadastrarComissao();
		                break;
		            case "Consultar Comissao":
		            	com.listarComissao();
		                break;
		            case "Listar Comissao":
		                break;
		            case "voltar":
		                mainADM();
		                break;
		            
		  }
	}
	
	public static void Sala() {
	    Interface sal = new Interface();
		 String[] opcoes = { "Cadastrar sala", "Listar Sala","voltar"};
		    var input = (String) JOptionPane.showInputDialog(null, "Opções para Sala:", "selecione uma opção", JOptionPane.QUESTION_MESSAGE, null, // Use
	                                                                // default                                                            // icon
		        opcoes, // Array of choices
		        opcoes[0]); // Initial choice
		        switch (input) {
		            case "Cadastrar sala":
		            	sal.cadastrar();
		                break;
		            case "Listar Sala":
		            	sal.listar();
		                break;
		            case "voltar":
		                mainADM();
		                break;
		            
		  }
	}
	public static void Sessao() {
	    Interface ses = new Interface();
		 String[] opcoes = { "Distribuir sessao", "Horario sessao", "Listar Sessao","voltar"};
		    var input = (String) JOptionPane.showInputDialog(null, "Opções para Sessao:", "selecione uma opção", JOptionPane.QUESTION_MESSAGE, null, // Use
	                                                                // default                                                            // icon
		        opcoes, // Array of choices
		        opcoes[0]); // Initial choice
		        switch (input) {
		            case "Distribuir sessao":
		            	ses.distribuir();
		                break;
		            case "Horario sessao":
		                break;
		            case "Listar Sessao":
		            	ses.listaSessao();
		                break;
		            case "voltar":
		                mainADM();
		                break;
		            
		  }
	}
	}
