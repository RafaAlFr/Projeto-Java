package main;

import javax.swing.JOptionPane;

import been.Comissao;
import controller.ControllerComissao;

public class ViewUsuario {
	static Comissao[] com = new Comissao[100];
	static int indice = 0;

	public void cadastrarComissao(){
		String email = JOptionPane.showInputDialog("email:");
		String senha = JOptionPane.showInputDialog("senha:");
		String instituicao = JOptionPane.showInputDialog("instituicao:");
		String areaConhecimento = JOptionPane.showInputDialog("area conhecimento:");
		String turno = JOptionPane.showInputDialog("turno:");
        String funcao = JOptionPane.showInputDialog("funcao:");
        String inkLattes = JOptionPane.showInputDialog("inkLattes:");

        
        Comissao C = new Comissao(email, senha, instituicao, areaConhecimento, turno, funcao, inkLattes);
        com[indice] = C;
        for(int i = 0; i<com.length;i++) {
        	if(com[i]!=null) {
	        	System.out.println(com[i]);
        	}
        }
        indice++;
        Menu.main(null);
	}
	
	public void listarComissao() {
		for(int i=0; i<com.length;i++) {
			if(com[i] != null) {
				JOptionPane.showInternalMessageDialog(null,com[i]);
			}
		}Menu.Comissao();
	}
	
	public void loginComissao() {
		String emailA = JOptionPane.showInputDialog("Digite o Email");
		String senhaA = JOptionPane.showInputDialog("Digite o Senha");

		for(int i = 0; i<com.length;i++) {
			if(com[i] !=null) {
				if(com[i].getEmail().equals(emailA) && com[i].getSenha().equals(senhaA)) {
					ControllerComissao com = new ControllerComissao();
					Comissao saidacom = com.CadastrarComissao(com);
					JOptionPane.showInternalMessageDialog(null, saidacom);
				}
			}
			
	}
}
}
