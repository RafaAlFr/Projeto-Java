package main;

import javax.swing.JOptionPane;
import been.Sala;
import been.Sessao;
import been.Evento;
import been.Comissao;
import Dao.DaoSala;
import Dao.DaoSessao;
import Dao.DaoEvento;
import Dao.DaoComissao;
import controller.ControllerSala;
import controller.ControllerSessao;
import controller.ControllerEvento;
import controller.ControllerComissao;

//------------------------------------------------------- Comissao -----------------------------------------------

public class Interface {
	static Sala[] sal = new Sala[20];
	static Sessao[] ses = new Sessao[20];
	static Evento[] eve = new Evento[1];
	static int indice = 0;
	
	
	//------------------------------------------------------- Evento -----------------------------------------------
	public void criar() {
        for(int o = 0; o<eve.length;o++) {
		if(eve[o]==null) {
        String nomeEvento = JOptionPane.showInputDialog("nome do evento");
        String descricao = JOptionPane.showInputDialog("descricao:");
        String emailEvento = JOptionPane.showInputDialog("emailEvento:");
        String tipo = JOptionPane.showInputDialog( "tipo:");
        String assuntoPrinc = JOptionPane.showInputDialog( "assuntoPrinc:");
        String local = JOptionPane.showInputDialog("local:");
        String cep = JOptionPane.showInputDialog("cep:");
        String estado = JOptionPane.showInputDialog("estado:");
        String cidade = JOptionPane.showInputDialog("cidade:");
        int dataInicio = Integer.parseInt(JOptionPane.showInputDialog("horarioInicio:"));
        int dataFim = Integer.parseInt(JOptionPane.showInputDialog("horarioFim:"));

        Evento E = new Evento(nomeEvento, descricao, emailEvento, tipo, assuntoPrinc, local, cep, estado, cidade, dataInicio, dataFim);	        
        eve[indice] = E;
        for(int i = 0; i<eve.length;i++) {
        	if(eve[i]!=null) {
	        	System.out.println(eve[i]);
        	}
        }
        indice++;
			Menu.Evento();
		}else {
			JOptionPane.showMessageDialog(null, "Já existe um evento");
			Menu.Evento();
		}
        }
   }
	public void listar() {
		for(int i=0; i<eve.length;i++) {
			if(eve[i] != null) {
				JOptionPane.showInternalMessageDialog(null,eve[i]);
			}
		}Menu.Evento();
	}
	public void editar() {
		
	}
	//--------------------------------------------------------- Sala --------------------------------------------------
	public void cadastrar() {
		String tipo = JOptionPane.showInputDialog("tipo:");
        int andar = Integer.parseInt(JOptionPane.showInputDialog( "andar:"));
        int numero = Integer.parseInt(JOptionPane.showInputDialog("numero:"));
        int limitePessoas = Integer.parseInt(JOptionPane.showInputDialog("limitePessoas:"));
        String temaSala = JOptionPane.showInputDialog("temaSala:");
        
        Sala S = new Sala(tipo, andar, numero, limitePessoas, temaSala);
        sal[indice] = S;
        for(int i = 0; i<sal.length;i++) {
        	if(sal[i]!=null) {
	        	System.out.println(sal[i]);
        	}
        }
        indice++;
        Menu.main(null);
	}

	public void listarSala() {
		for(int i=0; i<sal.length;i++) {
			if(sal[i] != null) {
				JOptionPane.showInternalMessageDialog(null,sal[i]);
			}
		}Menu.Sala();
	}
	//-------------------------------------------------- Sessao ------------------------------------------------
	public void distribuir() {
		int tempoSessao = Integer.parseInt(JOptionPane.showInputDialog( "tempo por sessao:"));
        int tempoApresentacao = 0;
        int idSessao = Integer.parseInt(JOptionPane.showInputDialog("id:"));
        String anfiteatro = JOptionPane.showInputDialog("anfiteatro?");
        
        Sessao S = new Sessao(tempoSessao, tempoApresentacao, idSessao, anfiteatro);
        ses[indice] = S;
        for(int i = 0; i<ses.length;i++) {
        	if(ses[i]!=null) {
	        	System.out.println(ses[i]);
        	}
        }
        indice++;
        hora();
	}
	public void hora() {

		for(int u=0; u<eve.length;u++) {
			if(eve[u] != null) {
				for(int i=0; i<ses.length;i++) {
					if(ses[i] != null) {
						int tempo = (int) (eve[u].getDataFim() - eve[u].getDataInicio());
			        	System.out.println(tempo);
			        	System.out.println(ses[i].getTempoSessao());
			        	int sessoes = (int) (tempo / ses[i].getTempoSessao());
			        	System.out.println(sessoes);	        	
			        	JOptionPane.showInternalMessageDialog(null, "Quantia de sessoes por dia : " + sessoes + "\n As sessões vão das: " + eve[u].getDataInicio() + " até " + eve[u].getDataFim());
			        	
					}
				}
				
			}
		}Menu.Sessao();
	}
	
	public void listaSessao() {
		for(int i=0; i<ses.length;i++) {
			if(ses[i] != null) {
				JOptionPane.showInternalMessageDialog(null,ses[i]);
			}
		}Menu.Sessao();
	}
	
	public void SalaSessao() {
		for(int u=0; u<sal.length;u++) {
			if(sal[u] != null) {
				for(int i=0; i<ses.length;i++) {
					if(ses[i] != null) {
						
					}
				}
			}
		}
		
	}
}

