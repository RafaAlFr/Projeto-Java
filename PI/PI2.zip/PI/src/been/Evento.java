package been;

public class Evento {
	private String nomeEvento;
    private String descricao;
    private String emailEvento;
    private String tipo;
    private String assuntoPrinc;
    private String local;
    private String cep;
    private String estado;
    private String cidade;
    private int dataInicio;
    private int dataFim;

    public Evento(String nomeEvento, String descricao, String emailEvento, String tipo, String assuntoPrinc, String local, String cep, String estado, String cidade, int dataInicio, int dataFim) {
        this.nomeEvento = nomeEvento;
        this.descricao = descricao;
        this.emailEvento = emailEvento;
        this.tipo = tipo;
        this.assuntoPrinc = assuntoPrinc;
        this.local = local;
        this.cep = cep;
        this.estado = estado;
        this.cidade = cidade;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
    }

    public String getNomeEvento() {
        return nomeEvento;
    }

    public void setNomeEvento(String nomeEvento) {
        this.nomeEvento = nomeEvento;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getEmailEvento() {
        return emailEvento;
    }

    public void setEmailEvento(String emailEvento) {
        this.emailEvento = emailEvento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getAssuntoPrinc() {
        return assuntoPrinc;
    }

    public void setAssuntoPrinc(String assuntoPrinc) {
        this.assuntoPrinc = assuntoPrinc;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public int getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(int dataInicio) {
        this.dataInicio = dataInicio;
    }

    public int getDataFim() {
        return dataFim;
    }

    public void setDataFim(int dataFim) {
        this.dataFim = dataFim;
    }

    @Override
    public String toString() {
        return "Evento{" + "\n nomeEvento=" + nomeEvento + "\n descricao=" + descricao + "\n emailEvento=" + emailEvento + "\n tipo=" + tipo + "\n assuntoPrinc=" + assuntoPrinc + "\n local=" + local + "\n cep=" + cep + "\n estado=" + estado + "\n cidade=" + cidade + "\n dataInicio=" + dataInicio + "\n dataFim=" + dataFim + '}';
    }
    
    
}
