package been;

public class Comissao {
	private String email;
    private String senha;
    private String instituicao;
    private String areaConhecimento;
    private String turno;
    private String funcao;
    private String inkLattes;

    public Comissao(String email, String senha, String instituicao, String areaConhecimento, String turno, String funcao, String inkLattes) {
        this.email = email;
        this.senha = senha;
        this.instituicao = instituicao;
        this.areaConhecimento = areaConhecimento;
        this.turno = turno;
        this.funcao = funcao;
        this.inkLattes = inkLattes;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }

    public String getAreaConhecimento() {
        return areaConhecimento;
    }

    public void setAreaConhecimento(String areaConhecimento) {
        this.areaConhecimento = areaConhecimento;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public String getInkLattes() {
        return inkLattes;
    }

    public void setInkLattes(String inkLattes) {
        this.inkLattes = inkLattes;
    }

    @Override
    public String toString() {
        return "Comissao{" + "email=" + email + "\n senha=" + senha + "\n instituicao=" + instituicao + "\n areaConhecimento=" + areaConhecimento + "\n turno=" + turno + "\n funcao=" + funcao + "\n inkLattes=" + inkLattes + '}';
    }
}
